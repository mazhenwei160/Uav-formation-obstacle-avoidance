%����-����45���ַ���
function [State] = Simu_RK_Traj(State, dux_u, duy_u, duz_u, SimStep, time)

    %��RK45����һ������    
    K_1 = zeros(6,1);
    K_2 = zeros(6,1);
    K_3 = zeros(6,1);
    K_4 = zeros(6,1);
    tempState = zeros(6,1);

    %��һ��
    dx = Simu_Dynamics_Traj(State, dux_u, duy_u, duz_u,  time);
    for i=1:6
        K_1(i) = SimStep * dx(i);
    end
    
    %�ڶ���
    for i=1:6
        tempState(i) = State(i) + 0.5 * K_1(i);        
    end
    
    dx = Simu_Dynamics_Traj(tempState, dux_u, duy_u, duz_u, time);

    for i=1:6
        K_2(i) = SimStep * dx(i);
    end
    
    %������
    for i=1:6
        tempState(i) = State(i) + 0.5 * K_2(i);        
    end

    dx = Simu_Dynamics_Traj(tempState, dux_u, duy_u, duz_u, time);
    
    for i=1:6
        K_3(i) = SimStep * dx(i);
    end
    
    %���Ĳ�
    for i=1:6
        tempState(i) = State(i) + K_3(i);        
    end
    
    dx = Simu_Dynamics_Traj(tempState, dux_u, duy_u, duz_u, time);
    
    for i=1:6
        K_4(i) = SimStep * dx(i);
    end
    
    %���
    for i=1:6
        State(i) = State(i) + (K_1(i) + 2*K_2(i) + 2*K_3(i) + K_4(i))/6;
    end
    
end
