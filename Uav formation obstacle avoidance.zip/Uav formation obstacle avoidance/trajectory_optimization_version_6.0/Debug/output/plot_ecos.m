close all;

%---------------------------------------------------------------%
%------------------------ 问题涉及常量 -------------------------%
%---------------------------------------------------------------%

R0        = 6378140;          %等效地球半径
g0        = 9.8;              %海平面重力加速度

V_ref     = sqrt(g0*R0);       %无量纲因子
R_ref     = R0;
T_ref     = sqrt(R0/g0);

%总迭代数
num = load('optimal_N.txt');
total_count=num(1,1);

index=0;
x = [];
y = [];
z = [];
vx = [];
vy = [];
vz = [];
ux = [];
uy = [];
uz = [];
dux = [];
duy = [];
duz = [];
u_2 = [];
A_ori = load('input_data.txt');
B_ori = load('input_control.txt');

time = A_ori(11,:).*T_ref;
x = [x;A_ori(1,:).*R_ref];
y = [y;A_ori(2,:).*R_ref];
z = [z;A_ori(3,:).*R_ref];
vx = [vx;A_ori(4,:).*V_ref];
vy = [vy;A_ori(5,:).*V_ref];
vz = [vz;A_ori(6,:).*V_ref];
ux = [ux;A_ori(7,:)];
uy = [uy;A_ori(8,:)];
uz = [uz;A_ori(9,:)];
u_2 = [u_2;A_ori(7,:).*A_ori(7,:)+A_ori(8,:).*A_ori(8,:)+A_ori(9,:).*A_ori(9,:)];
dux = [dux;B_ori(1,2:end)];
duy = [duy;B_ori(2,2:end)];
duz = [duz;B_ori(3,2:end)];
while index<total_count
    file_name_states = strcat('optimal_trajectory_',num2str(index),'.txt');
    file_name_control = strcat('optimal_control_',num2str(index),'.txt');
    A = load(file_name_states);
    B = load(file_name_control);
    x = [x;A(1,:).*R_ref];
    y = [y;A(2,:).*R_ref];
    z = [z;A(3,:).*R_ref];
    vx = [vx;A(4,:).*V_ref];
    vy = [vy;A(5,:).*V_ref];
    vz = [vz;A(6,:).*V_ref];
    ux = [ux;A(7,:)];
    uy = [uy;A(8,:)];
    uz = [uz;A(9,:)];
    u_2 = [u_2;A(7,:).*A(7,:)+A(8,:).*A(8,:)+A(9,:).*A(9,:)];
    dux = [dux;B(1,:)];
    duy = [duy;B(2,:)];
    duz = [duz;B(3,:)];
    index = index+1;
end
    
%%绘图
str = cell(total_count+1,1);
str1 = cell(total_count,1);

figure(1);
for i=1:total_count+1
    if i==total_count+1
        plot(time,x(i,:),'k-*','LineWidth',2);
    else 
        plot(time,x(i,:),'-o');
    end
    if i==1
        str{i} = '初始解';
    else
        str{i} = ['迭代',num2str(i-1)];
    end
    hold on;
end
xlabel('时间');
ylabel('x');
title('状态x变化');
legend(str);
%legend('迭代1','迭代2','迭代3');

figure(2);
for i=1:total_count+1
    if i==total_count+1
        plot(time,y(i,:),'k-*','LineWidth',2);
    else 
        plot(time,y(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('y');
title('状态y变化');
legend(str);


figure(3);
for i=1:total_count+1
    if i==total_count+1
        plot(time,z(i,:),'k-*','LineWidth',2);
    else 
        plot(time,z(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('z');
title('状态z变化');
legend(str);


figure(4);
for i=1:total_count+1
    if i==total_count+1
        plot(time,vx(i,:),'k-*','LineWidth',2);
    else 
        plot(time,vx(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('vx');
title('状态vx变化');
legend(str);

figure(5);
for i=1:total_count+1
    if i==total_count+1
        plot(time,vy(i,:),'k-*','LineWidth',2);
    else 
        plot(time,vy(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('vy');
title('状态vy变化');
legend(str);

figure(6);
for i=1:total_count+1
    if i==total_count+1
        plot(time,vz(i,:),'k-*','LineWidth',2);
    else 
        plot(time,vz(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('vz');
title('状态vz变化');
legend(str);

figure(7);
for i=1:total_count+1
    if i==total_count+1
        plot(time,ux(i,:),'k-*','LineWidth',2);
    else 
        plot(time,ux(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('ux');
title('状态ux变化');
legend(str);

figure(8);
for i=1:total_count+1
    if i==total_count+1
        plot(time,uy(i,:),'k-*','LineWidth',2);
    else 
        plot(time,uy(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('uy');
title('状态uy变化');
legend(str);

figure(9);
for i=1:total_count+1
    if i==total_count+1
        plot(time,uz(i,:),'k-*','LineWidth',2);
    else 
        plot(time,uz(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('uz');
title('状态uz变化');
legend(str);

figure(10);
for i=1:total_count+1
    if i==total_count+1
        plot(time,u_2(i,:),'k-*','LineWidth',2);
    else 
        plot(time,u_2(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('u_2');
title('状态 ux^2+uy^2+uz^2 变化');
legend(str);
    

figure(11);
for i=1:total_count+1
    if i==total_count+1
        plot(time(2:end),dux(i,:),'k-*','LineWidth',2);
    else
        plot(time(2:end),dux(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('dux');
title('控制dux变化');
legend(str);

figure(12);
for i=1:total_count+1
        if i==total_count+1
        plot(time(2:end),duy(i,:),'k-*','LineWidth',2);
    else
        plot(time(2:end),duy(i,:),'-o');
    end
    hold on;
end
xlabel('时间')
ylabel('duy');
title('控制duy变化');
legend(str);

figure(13);
for i=1:total_count+1
        if i==total_count+1
        plot(time(2:end),duz(i,:),'k-*','LineWidth',2);
    else
        plot(time(2:end),duz(i,:),'-o');
    end
    hold on;
end
xlabel('时间');
ylabel('duz');
title('控制duz变化');
legend(str);