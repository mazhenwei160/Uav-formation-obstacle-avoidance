%����-����45���ַ���
function [State] = Simu_RK_Traj_1(State, dux_u, duy_u, duz_u, SimStep, time)

    %��RK45����һ������    
    K_1 = zeros(9,1);
    K_2 = zeros(9,1);
    K_3 = zeros(9,1);
    K_4 = zeros(9,1);
    tempState = zeros(9,1);

    %��һ��
    dx = Simu_Dynamics_Traj_1(State, dux_u, duy_u, duz_u,  time);
    for i=1:9
        K_1(i) = SimStep * dx(i);
    end
    
    %�ڶ���
    for i=1:9
        tempState(i) = State(i) + 0.5 * K_1(i);        
    end
    
    dx = Simu_Dynamics_Traj_1(tempState, dux_u, duy_u, duz_u, time);

    for i=1:9
        K_2(i) = SimStep * dx(i);
    end
    
    %������
    for i=1:9
        tempState(i) = State(i) + 0.5 * K_2(i);        
    end

    dx = Simu_Dynamics_Traj_1(tempState, dux_u, duy_u, duz_u, time);
    
    for i=1:9
        K_3(i) = SimStep * dx(i);
    end
    
    %���Ĳ�
    for i=1:9
        tempState(i) = State(i) + K_3(i);        
    end
    
    dx = Simu_Dynamics_Traj_1(tempState, dux_u, duy_u, duz_u, time);
    
    for i=1:9
        K_4(i) = SimStep * dx(i);
    end
    
    %���
    for i=1:9
        State(i) = State(i) + (K_1(i) + 2*K_2(i) + 2*K_3(i) + K_4(i))/6;
    end
    
end
