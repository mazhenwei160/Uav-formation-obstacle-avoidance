%---------------------------------------------------------------%
%------------------------ �����漰���� -------------------------%
%---------------------------------------------------------------%
close all;
clear;

clc;
R0        = 6378140;          %��Ч����뾶
g0        = 9.8;              %��ƽ���������ٶ�

V_ref     = sqrt(g0*R0);       %����������
R_ref     = R0;
T_ref     = sqrt(R0/g0);
    


%---------------------------------------------------------------%
%------------------------- ��ȡ�Ż���� ------------------------%
%---------------------------------------------------------------%

C = load('input_data.txt');
time = C(11,:)*T_ref;

A = load('optimal_trajectory.txt');
x = A(1,:).*R_ref;
y = A(2,:).*R_ref;
z = A(3,:).*R_ref;
Vx = A(4,:).*V_ref;
Vy = A(5,:).*V_ref;
Vz = A(6,:).*V_ref;
ux = A(7,:);
uy = A(8,:);
uz = A(9,:);

D = load('input_control.txt');
dux0 = D(1,1);
duy0 = D(2,1);
duz0 = D(3,1);

B = load('optimal_control.txt');
duxi = B(1,:);
duyi = B(2,:);
duzi = B(3,:);

% dux = [dux0, duxi];
% duy = [duy0, duyi];
% duz = [duz0, duzi];
% dux0 = 0.09;
% duy0 = 0.004;
% duz0 = 0.002;
dux = [dux0, duxi];
duy = [duy0, duyi];
duz = [duz0, duzi];



V = sqrt(Vx.*Vx+Vy.*Vy+Vz.*Vz);
r = sqrt(x.*x+y.*y+z.*z)-R0;

u1=ux.*ux+uy.*uy+uz.*uz;

    
%---------------------------------------------------------------%
%------------------------- �켣��ʼ״̬ ------------------------%
%---------------------------------------------------------------%

xI_0=x(1);        
yI_0=y(1);
zI_0=z(1);
VxI_0=Vx(1);
VyI_0=Vy(1);
VzI_0=Vz(1);
uxI_0=ux(1);
uyI_0=uy(1);
uzI_0=uz(1);

%---------------------------------------------------------------%
%-------------------- ��ֵ�Ż��������������� -------------------%
%---------------------------------------------------------------%
Step = 0.01;
Time_Interp   = (time(1):Step:time(length(time)))';
NumOfInterp   = length(Time_Interp);
dux_Interp    = zeros(NumOfInterp,1);
duy_Interp    = zeros(NumOfInterp,1);
duz_Interp    = zeros(NumOfInterp,1);



% dux_Interp = interp1(time(1:end),dux,Time_Interp,'v5cubic','extrap');
% duy_Interp = interp1(time(1:end),duy,Time_Interp,'v5cubic','extrap');
% duz_Interp = interp1(time(1:end),duz,Time_Interp,'v5cubic','extrap');

dux_Interp = interp1(time(1:end),dux,Time_Interp,'linear','extrap');
duy_Interp = interp1(time(1:end),duy,Time_Interp,'linear','extrap');
duz_Interp = interp1(time(1:end),duz,Time_Interp,'linear','extrap');



%---------------------------------------------------------------%
%----------------------------- ���� ----------------------------%
%---------------------------------------------------------------%
Number	= length(Time_Interp);
State	= zeros(Number,9);
State(1,1) = xI_0;       State(1,2) = yI_0;       State(1,3) = zI_0;
State(1,4) = VxI_0;      State(1,5) = VyI_0;      State(1,6) = VzI_0;
State(1,7) = uxI_0;      State(1,8) = uyI_0;      State(1,9) = uzI_0;
for i=1:Number-1
    State(i+1,:) = Simu_RK_Traj_1(State(i,:), dux_Interp(i), duy_Interp(i), duz_Interp(i), Step, Time_Interp(i));
end

time_traj = Time_Interp;
x_traj = State(:,1);
y_traj = State(:,2);
z_traj = State(:,3);
Vx_traj = State(:,4);
Vy_traj = State(:,5);
Vz_traj = State(:,6);
ux_traj = State(:,7);
uy_traj = State(:,8);
uz_traj = State(:,9);

V_traj = sqrt(Vx_traj.*Vx_traj+Vy_traj.*Vy_traj+Vz_traj.*Vz_traj);
r_traj = sqrt(x_traj.*x_traj+y_traj.*y_traj+z_traj.*z_traj)-R0;




%---------------------------------------------------------------%
%----------------------------- ��ͼ ----------------------------%
%---------------------------------------------------------------%
plot_true = 1;
if (plot_true)
    figure(1)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, Vx,'o-', 'linewidth',2);
    plot(time_traj, Vx_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('Vx, m/s','Fontname', 'Times New Roman');

    figure(2)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, Vy,'o-', 'linewidth',2);
    plot(time_traj, Vy_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('Vy, m/s','Fontname', 'Times New Roman');

    figure(3)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, Vz,'o-', 'linewidth',2);
    plot(time_traj, Vz_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('Vz, m/s','Fontname', 'Times New Roman');

    figure(4)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, x,'o-', 'linewidth',2);
    plot(time_traj, x_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('x, m','Fontname', 'Times New Roman');

    figure(5)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, y,'o-', 'linewidth',2);
    plot(time_traj, y_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('y, m','Fontname', 'Times New Roman');

    figure(6)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, z,'o-', 'linewidth',2);
    plot(time_traj, z_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('z, m','Fontname', 'Times New Roman');

    figure(7)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, ux,'o-', 'linewidth',2);
    plot(time_traj, ux_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('ux','Fontname', 'Times New Roman');

    figure(8)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, uy,'o-', 'linewidth',2);
    plot(time_traj, uy_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('uy','Fontname', 'Times New Roman');

    figure(9)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, uz,'o-', 'linewidth',2);
    plot(time_traj, uz_traj,'-.', 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('uz','Fontname', 'Times New Roman');

    figure(10)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, r./1000,'o-','linewidth',2);
    plot(time_traj, r_traj./1000,'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('r, km','Fontname', 'Times New Roman');

    figure(11)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, V,'o-', 'linewidth',2);
    plot(time_traj, V_traj, 'linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('V, m/s','Fontname', 'Times New Roman');
    
%       figure(12)
%     title('Ŀ������������ϵ');
%     grid on;hold on;
%     plot(time(2:end), dux,'o-','linewidth',2);
%     xlabel('Time, s','Fontname', 'Times New Roman');
%     ylabel('dux, m/s','Fontname', 'Times New Roman');
%     
%        figure(13)
%     title('Ŀ������������ϵ');
%     grid on;hold on;
%     plot(time(2:end), duy,'o-','linewidth',2);
%     xlabel('Time, s','Fontname', 'Times New Roman');
%     ylabel('duy, m/s','Fontname', 'Times New Roman');
%     
%            figure(14)
%     title('Ŀ������������ϵ');
%     grid on;hold on;
%     plot(time(2:end), duz,'o-','linewidth',2);
%     xlabel('Time, s','Fontname', 'Times New Roman');
%     ylabel('duz, m/s','Fontname', 'Times New Roman');

      figure(12)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, dux,'o-','linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('dux, m/s','Fontname', 'Times New Roman');
    
       figure(13)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, duy,'o-','linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('duy, m/s','Fontname', 'Times New Roman');
    
           figure(14)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, duz,'o-','linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('duz, m/s','Fontname', 'Times New Roman');

               figure(15)
    title('Ŀ������������ϵ');
    grid on;hold on;
    plot(time, u1,'o-','linewidth',2);
    xlabel('Time, s','Fontname', 'Times New Roman');
    ylabel('u1, m/s','Fontname', 'Times New Roman');

end



