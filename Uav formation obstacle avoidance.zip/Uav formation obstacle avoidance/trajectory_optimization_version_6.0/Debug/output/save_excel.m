dense_A = load('dense_A.txt');
xlswrite('dense_A.xlsx',dense_A);
dense_G = load('dense_G.txt');
xlswrite('dense_G.xlsx',dense_G);