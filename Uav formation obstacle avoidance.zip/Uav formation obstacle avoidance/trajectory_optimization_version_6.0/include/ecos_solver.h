#pragma once
#ifndef ECOS_SOLVER_H
#define ECOS_SOLVER_H
#include "ecos.h"
#include "trajectory_optimization.h"


pwork * ecos_setup_optimization(optimize_parameters *para);


idxint ecos_solve_optimazation(pwork *work, trajectory *traj, control *contr);


void update_optimization(pwork *work, optimize_parameters *para);


void optimization_cleanup(pwork *work, optimize_parameters *para, trajectory *traj, control *contr, trajectory *old_traj);

#endif 
