#pragma once
#ifndef INPUT_PROBLEM_H
#define INPUT_PROBLEM_H
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
# include <math.h>
#include "glblopts.h"


//����ȫ�ֲ���
#define PI 3.141592653
#define g0 9.8
#define R0 6378140.0
#define GM 3.986005e+14
#define I_sp_Normal 2971
#define dMass 34.04
#define V_ref 7.906059195326076e+03
#define T_ref 8.067407342169465e+02

pfloat a_ref = g0;
pfloat R_ref = R0;

//��������
idxint ITER_NUM = 0;
idxint COLL_NUM = 0;

pfloat delta_x = 100000.0 / 6378140.0;
pfloat delta_y = 100000.0 / 6378140.0;
pfloat delta_vx = 4000.0 / 7.906059195326076e+03;
pfloat delta_vy = 4000.0 / 7.906059195326076e+03;
pfloat dux_max = 0.01;
pfloat duy_max = 0.01;
pfloat duz_max = 0.01;

//�������ʱ��
pfloat t0;
pfloat tf;
//��ʼ�켣
pfloat I_sp_Percent;
pfloat T;

#endif
