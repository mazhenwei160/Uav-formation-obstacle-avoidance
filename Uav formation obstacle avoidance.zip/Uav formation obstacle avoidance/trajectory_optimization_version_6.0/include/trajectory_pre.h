#pragma once
#ifndef TRAJECTORY_PRE_H
#define TRAJECTORY_PRE_H

#include "trajectory_optimization.h"

trajectory *prepare_trajectory(pfloat t0, int COLL_NUM, int traj_length);


trajectory *read_standered_trajectory(int traj_length);


trajectory *init_trajectory(trajectory *FG_stand_traj, pfloat start_time, int N, int traj_length);


control* read_standard_control(idxint COLL_NUM, int traj_length, pfloat start_time);

#endif
