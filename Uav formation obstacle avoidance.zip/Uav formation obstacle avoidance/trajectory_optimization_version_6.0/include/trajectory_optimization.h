#pragma once
#ifndef TRAJECTORY_OPTIMIZATION_H
#define TRAJECTORY_OPTIMIZATION_H
#include "spla.h"
#include "glblopts.h"
#include "ecos.h"
#include <stdio.h>
#include <stdbool.h>



#define PI     3.141592653
#define g      9.8          //����ϵ��
#define Length 0.228        //���������˻�������ĵ����ĵľ���
#define Mass   0.929        //���������˻�������



extern idxint ITER_NUM;
extern idxint MAX_ITER_NUM;
extern idxint COLL_NUM;
extern pfloat trust_exp_scale;
extern pfloat converg_Para;
extern pfloat U1_max;


extern pfloat delta_x;
extern pfloat delta_y;
extern pfloat delta_z;
extern pfloat delta_Vx;
extern pfloat delta_Vy;
extern pfloat delta_Vz;
extern pfloat delta_ux;
extern pfloat delta_uy;
extern pfloat delta_uz;
extern pfloat delta_dux;
extern pfloat delta_duy;
extern pfloat delta_duz;
extern pfloat delta_tf;


extern pfloat x_1;
extern pfloat y_1;
extern pfloat x_2;
extern pfloat y_2;
extern pfloat x_3;
extern pfloat y_3;
extern pfloat x_4;
extern pfloat y_4;


extern pfloat L_1;
extern pfloat L_2;
extern pfloat L_3;
extern pfloat L_4;


extern pfloat t0;


typedef struct trajectory 
{
	pfloat* time;

	pfloat *x;
	pfloat *y;
	pfloat *z;

	pfloat *Vx;
	pfloat *Vy;
	pfloat *Vz;

	pfloat *ux;
	pfloat *uy;
	pfloat *uz;

	pfloat tf;
}trajectory;

typedef struct control_stand
{

	pfloat* time;
	pfloat* dux;
	pfloat* duy;
	pfloat* duz;

}control_stand;


typedef struct control
{
	
	pfloat *dux;
	pfloat *duy;
	pfloat *duz;
}control;



typedef struct A_param
{
	
	pfloat k1;
	pfloat *l1;
	pfloat *b1;
	pfloat *l2;
	pfloat *b2;
	pfloat *l3;
	pfloat *b3;

	pfloat k2;
	pfloat *l4;
	pfloat *b4;
	pfloat *l5;
	pfloat *b5;
	pfloat *l6;
	pfloat *b6;

	pfloat *l7;
	pfloat *b7;
	pfloat *l8;
	pfloat *b8;
	pfloat *l9;
	pfloat *b9;

	pfloat *s1_x;
	pfloat *s1_y;
	pfloat *s2_x;
	pfloat *s2_y;
	pfloat *s3_x;
	pfloat *s3_y;
	pfloat *s4_x;
	pfloat *s4_y;

	pfloat *s_1;
	pfloat *s_2;
	pfloat *s_3;
	pfloat *s_4;

	pfloat *S_1;
	pfloat *S_2;
	pfloat *S_3;
	pfloat *S_4;
}A_param;


typedef struct optimize_paramers
{
	idxint n;		
	idxint m;		
	idxint p;		
	idxint l;		
	idxint n_cones;	
	idxint *q;		
	pfloat *c;		
	pfloat *b;		
	pfloat *h;	
	spmat *A;		
	spmat *G;		
	pfloat**D;		
}optimize_parameters;




optimize_parameters * parameterization(trajectory* traj, control* contr);


void update_parameters(optimize_parameters *all_param, trajectory *traj, control* contr);


void copy_trajectory(trajectory *traj, trajectory *old_traj);


void copy_control(control* contr, control* old_contr);


bool check_convergence(trajectory *old_traj, trajectory *traj);


void fprintf_vector(FILE* fp, pfloat* arry, int len);


void fprintf_vector_control(FILE* fp, pfloat* arry, int len);


void save_iterN(int iter_n);


void save_trajectory_control_iter(int iter_n, trajectory *traj, control *contr);


void save_optimal_solution(trajectory *traj, control *contr);


pfloat** GetRadua_MatrixD(int NumOfColl);

pfloat* GetRadua_Tau(int NumOfColl);

A_param* GetMatrixA_Param(trajectory *oldtrac, control* oldcontr, idxint NumOfCol);


spmat* Generate_MatrixA(pfloat **D, A_param *param, idxint NumOfCol);


void Update_MatrixA(spmat *MatrixA, pfloat **D, A_param *param, idxint NumOfCol);


pfloat* Generate_Vectorb(A_param *param, idxint NumOfCol, trajectory *oldtrac);


void Update_Vectorb(pfloat *b ,A_param *param, idxint NumOfCol, trajectory *oldtrac);


pfloat* Generate_Vectorc(idxint NumOfCol);


void Update_Vectorc(pfloat* c, idxint NumOfCol);


spmat* Generate_MatrixG(A_param* param, idxint NumOfCol);


void Update_MatrixG(spmat *MatrixG, A_param* param, idxint NumOfCol);


pfloat* Generate_Vectorh(idxint NumOfCol, A_param* param, trajectory * oldtrac, control* oldcontr);


void Update_Vectorh(pfloat *h ,idxint NumOfCol, A_param* param, trajectory * oldtrac, control* oldcontr);


optimize_parameters* GetAllParamers(trajectory *oldtrac, control *oldcontr, idxint NumOfCol);

#endif
