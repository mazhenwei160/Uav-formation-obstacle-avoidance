#pragma once
#pragma warning(disable : 4996)
#include "trajectory_optimization.h"
#include <stdlib.h>


idxint ITER_NUM = 0;


idxint COLL_NUM = 0;


idxint MAX_ITER_NUM = 100;


pfloat trust_exp_scale = 2;


pfloat converg_Para = 5e-4;


pfloat t0 = 0.0;


pfloat U1_max = 15.7321;



pfloat delta_x = 100;
pfloat delta_y = 100;
pfloat delta_z = 100;
pfloat delta_Vx = 20;
pfloat delta_Vy = 20;
pfloat delta_Vz = 20;
pfloat delta_ux = 15.7321;
pfloat delta_uy = 15.7321;
pfloat delta_uz = 15.7321;
pfloat delta_tf = 10;


pfloat delta_dux = 15.7321 * 0.2;
pfloat delta_duy = 15.7321 * 0.2;
pfloat delta_duz = 15.7321 * 0.2;

//�����ϰ�������
pfloat x_1 = 10;
pfloat y_1 = 8;
pfloat x_2 = 25;
pfloat y_2 = 25;
pfloat x_3 = 5;
pfloat y_3 = 30;
pfloat x_4 = 35;
pfloat y_4 = 10;

//���ð�ȫ����ģֵ
pfloat L_1 = (3 + Length + 0.5 + 1) * (3 + Length + 0.5 + 1);      //�ϰ�1���ĵ�Ϊ��10�� 8�����뾶Ϊ  3m���߶Ȳ��ޣ���ȫ����Ϊ0.5m�� �ӻ���������Ϊ1m
pfloat L_2 = (5 + Length + 0.5 + 1) * (5 + Length + 0.5 + 1);      //�ϰ�2���ĵ�Ϊ��25��25�����뾶Ϊ  5m���߶Ȳ��ޣ���ȫ����Ϊ0.5m�� �ӻ���������Ϊ1m
pfloat L_3 = (2.5 + Length + 0.5 + 1) * (2.5 + Length + 0.5 + 1);  //�ϰ�3���ĵ�Ϊ�� 5��30�����뾶Ϊ2.5m���߶Ȳ��ޣ���ȫ����Ϊ0.5m�� �ӻ���������Ϊ1m
pfloat L_4 = (2.5 + Length + 0.5 + 1) * (2.5 + Length + 0.5 + 1);  //�ϰ�4���ĵ�Ϊ��35��10�����뾶Ϊ2.5m���߶Ȳ��ޣ���ȫ����Ϊ0.5m�� �ӻ���������Ϊ1m




optimize_parameters * parameterization(trajectory *traj, control* contr)
{
	return GetAllParamers(traj , contr, COLL_NUM);
}

void update_parameters(optimize_parameters *all_param, trajectory *traj, control* contr)
{

	A_param *a_param = GetMatrixA_Param(traj, contr, COLL_NUM);


	Update_MatrixA(all_param->A, all_param->D, a_param, COLL_NUM);


	Update_Vectorb(all_param->b, a_param, COLL_NUM, traj);


	Update_MatrixG(all_param->G, a_param, COLL_NUM);

	Update_Vectorh(all_param->h, COLL_NUM, a_param, traj, contr);


	Update_Vectorc(all_param->c, COLL_NUM);


	FREE(a_param->l1);
	FREE(a_param->b1);
	FREE(a_param->l2);
	FREE(a_param->b2);
	FREE(a_param->l3);
	FREE(a_param->b3);
	FREE(a_param->l4);
	FREE(a_param->b4);
	FREE(a_param->l5);
	FREE(a_param->b5);
	FREE(a_param->l6);
	FREE(a_param->b6);
	FREE(a_param->l7);
	FREE(a_param->b7);
	FREE(a_param->l8);
	FREE(a_param->b8);
	FREE(a_param->l9);
	FREE(a_param->b9);
	FREE(a_param->s1_x);
	FREE(a_param->s2_x);
	FREE(a_param->s3_x);
	FREE(a_param->s4_x);
	FREE(a_param->s1_y);
	FREE(a_param->s2_y);
	FREE(a_param->s3_y);
	FREE(a_param->s4_y);
	FREE(a_param->s_1);
	FREE(a_param->s_2);
	FREE(a_param->s_3);
	FREE(a_param->s_4);
	FREE(a_param->S_1);
	FREE(a_param->S_2);
	FREE(a_param->S_3);
	FREE(a_param->S_4);
	FREE(a_param);
}


void copy_trajectory(trajectory *traj, trajectory *old_traj)
{

	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->x[i] = traj->x[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->y[i] = traj->y[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->z[i] = traj->z[i];


	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->Vx[i] = traj->Vx[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->Vy[i] = traj->Vy[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->Vz[i] = traj->Vz[i];


	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->ux[i] = traj->ux[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->uy[i] = traj->uy[i];
	for (int i = 0; i < COLL_NUM + 1; i++) old_traj->uz[i] = traj->uz[i];
	old_traj->tf = traj->tf;
}


void copy_control(control* contr, control* old_contr)
{

	for (int i = 0; i < COLL_NUM; i++) old_contr->dux[i] = contr->dux[i];
	for (int i = 0; i < COLL_NUM; i++) old_contr->duy[i] = contr->duy[i];
	for (int i = 0; i < COLL_NUM; i++) old_contr->duz[i] = contr->duz[i];
}


bool check_convergence(trajectory *old_traj, trajectory *traj)
{

	pfloat limit = converg_Para;

	pfloat residual = 0;

	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->x[i] - old_traj->x[i]);
	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->y[i] - old_traj->y[i]);
	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->z[i] - old_traj->z[i]);

	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->Vx[i] - old_traj->Vx[i]);
	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->Vy[i] - old_traj->Vy[i]);
	for (int i = 0; i < COLL_NUM + 1; i++) residual += fabs(traj->Vz[i] - old_traj->Vz[i]);

	printf("State convergence residual:%e\n", residual);
	printf("===============================================================\n\n\n");
	return (residual < limit);
}

void fprintf_vector(FILE *fp, pfloat* arry, int len)
{
	fprintf(fp, "%.16f", arry[0]);
	for (int i = 1; i<len; i++) 
	{
		fprintf(fp, ", %.16f", arry[i]);
	}
	fprintf(fp, "\n");
}

void fprintf_vector_control(FILE *fp, pfloat* arry, int len)
{
	fprintf(fp, "%.16f", arry[0]);
	for (int i = 1; i<len; i++) 
	{
		fprintf(fp, ", %.16f", arry[i]);
	}
	fprintf(fp, "\n");
}

void save_iterN(int iter_n)
{

	char iterfilename[40] = "GD_ecos";

	char itersavename[50] = "output/";
	strcat(itersavename, iterfilename);

	FILE *fp = fopen(itersavename, "w");
	fprintf(fp, "%d", iter_n);
	fclose(fp);
}


void save_trajectory_control_iter(int iter_n, trajectory *traj, control *contr)
{

	char  index[50];
	sprintf(index, "_iter_%d.txt", iter_n);

	char trajfilename[40] = "GD_ecostraj";
	char contfilename[40] = "GD_ecoscont";


	char trajsavename[50] = "output/";
	strcat(trajsavename, trajfilename);

	FILE *fp = fopen(trajsavename, "w");

	fprintf_vector(fp, traj->x, COLL_NUM + 1);
	fprintf_vector(fp, traj->y, COLL_NUM + 1);
	fprintf_vector(fp, traj->z, COLL_NUM + 1);

	fprintf_vector(fp, traj->Vx, COLL_NUM + 1);
	fprintf_vector(fp, traj->Vy, COLL_NUM + 1);
	fprintf_vector(fp, traj->Vz, COLL_NUM + 1);

	fprintf_vector(fp, traj->ux, COLL_NUM + 1);
	fprintf_vector(fp, traj->uy, COLL_NUM + 1);
	fprintf_vector(fp, traj->uz, COLL_NUM + 1);
	fprintf(fp, "%lf\n", traj->tf);
	fclose(fp);

	char contsavename[40] = "output/";
	strcat(contsavename, contfilename);
	fp = fopen(contsavename, "w");
	fprintf_vector_control(fp, contr->dux, COLL_NUM);
	fprintf_vector_control(fp, contr->duy, COLL_NUM);
	fprintf_vector_control(fp, contr->duz, COLL_NUM);
	fclose(fp);
}




void save_optimal_solution(trajectory *traj, control *contr)
{
	FILE *fp;
	char trajfilename[40] = "GD_ecostraj.txt";
	char contfilename[40] = "GD_ecoscont.txt";
	char trajsavename[40] = "output/";
	strcat(trajsavename, trajfilename);

	fp = fopen(trajsavename, "w");

	fprintf_vector(fp, traj->x, COLL_NUM + 1);
	fprintf_vector(fp, traj->y, COLL_NUM + 1);
	fprintf_vector(fp, traj->z, COLL_NUM + 1);

	fprintf_vector(fp, traj->Vx, COLL_NUM + 1);
	fprintf_vector(fp, traj->Vy, COLL_NUM + 1);
	fprintf_vector(fp, traj->Vz, COLL_NUM + 1);

	fprintf_vector(fp, traj->ux, COLL_NUM + 1);
	fprintf_vector(fp, traj->uy, COLL_NUM + 1);
	fprintf_vector(fp, traj->uz, COLL_NUM + 1);
	fprintf(fp, "%lf\n", traj->tf);
	fclose(fp);


	char contsavename[40] = "output/";
	strcat(contsavename, contfilename);
	fp = fopen(contsavename, "w");
	fprintf_vector_control(fp, contr->dux, COLL_NUM);
	fprintf_vector_control(fp, contr->duy, COLL_NUM);
	fprintf_vector_control(fp, contr->duz, COLL_NUM);
	fclose(fp);
}




pfloat** GetRadua_MatrixD(int NumOfColl)
{
	pfloat old_Tau;

	pfloat**D;
	D = (pfloat **)MALLOC(sizeof(pfloat *) * NumOfColl);
	for (int i = 0; i < NumOfColl; i++)
	{
		D[i] = (pfloat *)MALLOC(sizeof(pfloat) * (NumOfColl + 1));
	}

	const pfloat eps_tau = 1e-15;

	pfloat *Tau = (pfloat*)MALLOC(sizeof(pfloat)*NumOfColl);
	pfloat *P = (pfloat*)MALLOC(sizeof(pfloat)*(NumOfColl + 1));


	for (int i = 0; i<NumOfColl; i++) Tau[i] = -cos(2 * PI *i / (2 * NumOfColl - 1));


	for (int i = 1; i<NumOfColl; i++)
	{
		old_Tau = 2.0;

		while (fabs(Tau[i] - old_Tau) > eps_tau)
		{
			old_Tau = Tau[i];

			P[0] = 1;
			P[1] = Tau[i];
			for (int j = 1; j<NumOfColl; j++)
			{
				P[j + 1] = ((2 * j + 1)*Tau[i] * P[j] - j*P[j - 1]) / (j + 1);
			}
			Tau[i] = old_Tau - (Tau[i] - 1)*(P[NumOfColl] + P[NumOfColl - 1]) / (P[NumOfColl] - P[NumOfColl - 1]) / NumOfColl;
		}
	}


	pfloat *Tau_Plus = (pfloat*)MALLOC(sizeof(pfloat)*(NumOfColl + 1));

	for (int i = 0; i<NumOfColl; i++)
	{
		Tau_Plus[i] = Tau[i];
	}
	Tau_Plus[NumOfColl] = 1.0;


	int row_D = NumOfColl;
	int column_D = NumOfColl + 1;

	pfloat **D_inFunc = (pfloat**)MALLOC(sizeof(pfloat*)*NumOfColl);
	for (int i = 0; i < row_D; i++)
	{
		D_inFunc[i] = (pfloat *)MALLOC(sizeof(pfloat) * (NumOfColl + 1));
	}
		
	for (int i = 0; i<column_D; i++)
	{
		for (int j = 0; j<row_D; j++)
		{
			if (j != i)
			{
				D_inFunc[j][i] = 1.0;
				for (int p = 0; p<column_D; p++)
				{
					if (p != i && p != j)
					{
						D_inFunc[j][i] = D_inFunc[j][i] * (Tau_Plus[j] - Tau_Plus[p]) / (Tau_Plus[i] - Tau_Plus[p]);
					}
					else if (p == j)
					{
						D_inFunc[j][i] = D_inFunc[j][i] / (Tau_Plus[i] - Tau_Plus[p]);
					}
				}
			}
			else
			{
				D_inFunc[j][i] = 0.0;
				for (int m = 0; m<column_D; m++)
				{
					if (m != i)
						D_inFunc[j][i] = D_inFunc[j][i] + 1.0 / (Tau_Plus[i] - Tau_Plus[m]);
				}
			}
		}
	}


	for (int i = 0; i<NumOfColl; i++)
	{
		for (int j = 0; j<(NumOfColl + 1); j++)
		{
			D[i][j] = 2.0*D_inFunc[i][j];
		}
	}


	for (int i = 0; i < NumOfColl; i++)
	{
		FREE(D_inFunc[i]);
	}
	FREE(D_inFunc);
	FREE(Tau);
	FREE(P);
	FREE(Tau_Plus);


	return D;
}


pfloat* GetRadua_Tau(int NumOfColl)
{
	pfloat old_Tau;

	pfloat** D;
	D = (pfloat**)MALLOC(sizeof(pfloat*) * NumOfColl);
	for (int i = 0; i < NumOfColl; i++)
	{
		D[i] = (pfloat*)MALLOC(sizeof(pfloat) * (NumOfColl + 1));
	}

	const pfloat eps_tau = 1e-15;

	pfloat* Tau = (pfloat*)MALLOC(sizeof(pfloat) * NumOfColl);
	pfloat* P = (pfloat*)MALLOC(sizeof(pfloat) * (NumOfColl + 1));


	for (int i = 0; i < NumOfColl; i++) Tau[i] = -cos(2 * PI * i / (2 * NumOfColl - 1));

	for (int i = 1; i < NumOfColl; i++)
	{
		old_Tau = 2.0;
		while (fabs(Tau[i] - old_Tau) > eps_tau)
		{
			old_Tau = Tau[i];

			P[0] = 1;
			P[1] = Tau[i];
			for (int j = 1; j < NumOfColl; j++)
			{
				P[j + 1] = ((2 * j + 1) * Tau[i] * P[j] - j * P[j - 1]) / (j + 1);
			}
			Tau[i] = old_Tau - (Tau[i] - 1) * (P[NumOfColl] + P[NumOfColl - 1]) / (P[NumOfColl] - P[NumOfColl - 1]) / NumOfColl;
		}
	}

	pfloat* Tau_Plus = (pfloat*)MALLOC(sizeof(pfloat) * (NumOfColl + 1));

	for (int i = 0; i < NumOfColl; i++)
	{
		Tau_Plus[i] = Tau[i];
	}
	Tau_Plus[NumOfColl] = 1.0;

	int row_D = NumOfColl;
	int column_D = NumOfColl + 1;

	pfloat** D_inFunc = (pfloat**)MALLOC(sizeof(pfloat*) * NumOfColl);
	for (int i = 0; i < row_D; i++)
	{
		D_inFunc[i] = (pfloat*)MALLOC(sizeof(pfloat) * (NumOfColl + 1));
	}

	for (int i = 0; i < column_D; i++)
	{
		for (int j = 0; j < row_D; j++)
		{
			if (j != i)
			{
				D_inFunc[j][i] = 1.0;
				for (int p = 0; p < column_D; p++)
				{
					if (p != i && p != j)
					{
						D_inFunc[j][i] = D_inFunc[j][i] * (Tau_Plus[j] - Tau_Plus[p]) / (Tau_Plus[i] - Tau_Plus[p]);
					}
					else if (p == j)
					{
						D_inFunc[j][i] = D_inFunc[j][i] / (Tau_Plus[i] - Tau_Plus[p]);
					}
				}
			}
			else
			{
				D_inFunc[j][i] = 0.0;
				for (int m = 0; m < column_D; m++)
				{
					if (m != i)
						D_inFunc[j][i] = D_inFunc[j][i] + 1.0 / (Tau_Plus[i] - Tau_Plus[m]);
				}
			}
		}
	}

	for (int i = 0; i < NumOfColl; i++)
	{
		for (int j = 0; j < (NumOfColl + 1); j++)
		{
			D[i][j] = 2.0 * D_inFunc[i][j];
		}
	}

	for (int i = 0; i < NumOfColl; i++)
	{
		FREE(D_inFunc[i]);
		FREE(D[i]);
	}
	FREE(D_inFunc);
	FREE(D);
	FREE(Tau);
	FREE(P);

	return Tau_Plus;
}


A_param* GetMatrixA_Param(trajectory *oldtrac, control* oldcontr, idxint N)
{

	A_param *a_param = (A_param*)MALLOC(sizeof(A_param));

	a_param->k1 = t0 - oldtrac->tf;
	a_param->k2 = (t0 - oldtrac->tf) / Mass;

	a_param->l1 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b1 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l2 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b2 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l3 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b3 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l4 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b4 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l5 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b5 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l6 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b6 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l7 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b7 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l8 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b8 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->l9 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->b9 = (pfloat*)MALLOC(sizeof(pfloat) * N);
	a_param->s1_x = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s1_y = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s2_x = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s2_y = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s3_x = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s3_y = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s4_x = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s4_y = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s_1 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s_2 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s_3 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->s_4 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->S_1 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->S_2 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->S_3 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	a_param->S_4 = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));

	for (int i = 0; i < N; i++)
	{
		a_param->l1[i] = -oldtrac->Vx[i];
		a_param->b1[i] = -oldtrac->tf * oldtrac->Vx[i];
		a_param->l2[i] = -oldtrac->Vy[i];
		a_param->b2[i] = -oldtrac->tf * oldtrac->Vy[i];
		a_param->l3[i] = -oldtrac->Vz[i];
		a_param->b3[i] = -oldtrac->tf * oldtrac->Vz[i];
		a_param->l4[i] = -oldtrac->ux[i] / Mass;
		a_param->b4[i] = -oldtrac->tf * oldtrac->ux[i] / Mass;
		a_param->l5[i] = -oldtrac->uy[i] / Mass;
		a_param->b5[i] = -oldtrac->tf * oldtrac->uy[i] / Mass;
		a_param->l6[i] = -oldtrac->uz[i] / Mass + g;
		a_param->b6[i] = -oldtrac->tf * oldtrac->uz[i] / Mass + t0 * g;
		a_param->l7[i] = -oldcontr->dux[i];
		a_param->b7[i] = -oldtrac->tf * oldcontr->dux[i];
		a_param->l8[i] = -oldcontr->duy[i];
		a_param->b8[i] = -oldtrac->tf * oldcontr->duy[i];
		a_param->l9[i] = -oldcontr->duz[i];
		a_param->b9[i] = -oldtrac->tf * oldcontr->duz[i];
	}

	for (int i = 0; i <= N; i++)
	{
		a_param->s1_x[i] = -2 * (oldtrac->x[i] - x_1);
		a_param->s1_y[i] = -2 * (oldtrac->y[i] - y_1);
		a_param->s2_x[i] = -2 * (oldtrac->x[i] - x_2);
		a_param->s2_y[i] = -2 * (oldtrac->y[i] - y_2);
		a_param->s3_x[i] = -2 * (oldtrac->x[i] - x_3);
		a_param->s3_y[i] = -2 * (oldtrac->y[i] - y_3);
		a_param->s4_x[i] = -2 * (oldtrac->x[i] - x_4);
		a_param->s4_y[i] = -2 * (oldtrac->y[i] - y_4);
		a_param->s_1[i] = -(oldtrac->x[i] - x_1) * (oldtrac->x[i] - x_1) - (oldtrac->y[i] - y_1) * (oldtrac->y[i] - y_1) + L_1;
		a_param->s_2[i] = -(oldtrac->x[i] - x_2) * (oldtrac->x[i] - x_2) - (oldtrac->y[i] - y_2) * (oldtrac->y[i] - y_2) + L_2;
		a_param->s_3[i] = -(oldtrac->x[i] - x_3) * (oldtrac->x[i] - x_3) - (oldtrac->y[i] - y_3) * (oldtrac->y[i] - y_3) + L_3;
		a_param->s_4[i] = -(oldtrac->x[i] - x_4) * (oldtrac->x[i] - x_4) - (oldtrac->y[i] - y_4) * (oldtrac->y[i] - y_4) + L_4;
		a_param->S_1[i] = a_param->s_1[i] - a_param->s1_x[i] * oldtrac->x[i] - a_param->s1_y[i] * oldtrac->y[i];
		a_param->S_2[i] = a_param->s_2[i] - a_param->s2_x[i] * oldtrac->x[i] - a_param->s2_y[i] * oldtrac->y[i];
		a_param->S_3[i] = a_param->s_3[i] - a_param->s3_x[i] * oldtrac->x[i] - a_param->s3_y[i] * oldtrac->y[i];
		a_param->S_4[i] = a_param->s_4[i] - a_param->s4_x[i] * oldtrac->x[i] - a_param->s4_y[i] * oldtrac->y[i];
	}
	return a_param;
}


spmat* Generate_MatrixA(pfloat **D, A_param *param, idxint N)
{

	spmat *MatrixA = (spmat*)MALLOC(sizeof(spmat));

	MatrixA->m = 9 * N + 18;

	MatrixA->n = 12 * N + 10;

	MatrixA->nnz = 9 * N * (N + 1) + 18 * N + 18;

	MatrixA->jc = (idxint*)MALLOC(sizeof(idxint)*(MatrixA->n + 1));
	MatrixA->ir = (idxint*)MALLOC(sizeof(idxint)*(MatrixA->nnz));
	MatrixA->pr = (pfloat*)MALLOC(sizeof(pfloat)*(MatrixA->nnz));



	MatrixA->jc[0] = 0;

	for (int i = 1; i <= 3 * N + 3; i++)
	{
		if (i %(N + 1) == 1)
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 1;
		}
		else if (i % (N + 1) == 0)
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 1;
		}
		else
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N;
		}
	}

	for (int i = 3 * N + 4; i <= 6 * N + 6; i++)
	{
		if (i % (N + 1) == 1)
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 2;
		}
		else
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 1;
		}
	}

	for (int i = 6 * N + 7; i <= 9 * N + 9; i++)
	{
		if (i % (N + 1) == 1)
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 2;
		}
		else
		{
			MatrixA->jc[i] = MatrixA->jc[i - 1] + N + 1;
		}
	}

	for (int i = 9 * N + 10; i <= 12 * N + 9; i++)
	{
		MatrixA->jc[i] = MatrixA->jc[i - 1] + 1;
	}

	for (int i = 12 * N + 10; i <= 12 * N + 10; i++)
	{
		MatrixA->jc[i] = MatrixA->jc[i - 1] + 9 * N;
	}


	int count = 0;


	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N;
			MatrixA->pr[count - 1] = 1;
		}
		
		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 9;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 1;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 10;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 2 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 2;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 11;
			MatrixA->pr[count - 1] = 1;
		}	
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = i - 1;
			MatrixA->pr[count - 1] = param->k1;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 3 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 3;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 12;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = N + i - 1;
			MatrixA->pr[count - 1] = param->k1;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 4 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 4;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 13;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 2 * N + i - 1;
			MatrixA->pr[count - 1] = param->k1;

		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 5 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 5;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 14;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 3 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 6 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 6;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 15;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 4 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 7 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 7;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 16;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 5 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 8 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 8;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 17;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 6 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 7 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 8 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}


	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = i - 1;
		MatrixA->pr[count - 1] = param->l1[i - 1];
		MatrixA->ir[count++] = N + i - 1;
		MatrixA->pr[count - 1] = param->l2[i - 1];
		MatrixA->ir[count++] = 2 * N + i - 1;
		MatrixA->pr[count - 1] = param->l3[i - 1];
		MatrixA->ir[count++] = 3 * N + i - 1;
		MatrixA->pr[count - 1] = param->l4[i - 1];
		MatrixA->ir[count++] = 4 * N + i - 1;
		MatrixA->pr[count - 1] = param->l5[i - 1];
		MatrixA->ir[count++] = 5 * N + i - 1;
		MatrixA->pr[count - 1] = param->l6[i - 1];
		MatrixA->ir[count++] = 6 * N + i - 1;
		MatrixA->pr[count - 1] = param->l7[i - 1];
		MatrixA->ir[count++] = 7 * N + i - 1;
		MatrixA->pr[count - 1] = param->l8[i - 1];
		MatrixA->ir[count++] = 8 * N + i - 1;
		MatrixA->pr[count - 1] = param->l9[i - 1];
	}
	return MatrixA;
}


void Update_MatrixA(spmat *MatrixA, pfloat **D, A_param *param, idxint N)
{

	int count = 0;


	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 9;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 1;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 10;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 2 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 2;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 11;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = i - 1;
			MatrixA->pr[count - 1] = param->k1;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 3 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 3;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 12;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = N + i - 1;
			MatrixA->pr[count - 1] = param->k1;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 4 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 4;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 13;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 2 * N + i - 1;
			MatrixA->pr[count - 1] = param->k1;

		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 5 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 5;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 14;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 3 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 6 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 6;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 15;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 4 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 7 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 7;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 16;
			MatrixA->pr[count - 1] = 1;
		}
	}


	for (int i = 1; i <= N + 1; i++)
	{
		if (i < N + 1)
		{
			MatrixA->ir[count++] = 5 * N + i - 1;
			MatrixA->pr[count - 1] = param->k2;
		}

		for (int j = 0; j < N; j++)
		{
			MatrixA->ir[count++] = 8 * N + j;
			MatrixA->pr[count - 1] = D[j][i - 1];
		}

		if (i == 1)
		{
			MatrixA->ir[count++] = 9 * N + 8;
			MatrixA->pr[count - 1] = 1;
		}

		if (i == N + 1)
		{
			MatrixA->ir[count++] = 9 * N + 17;
			MatrixA->pr[count - 1] = 1;
		}
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 6 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 7 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = 8 * N + i - 1;
		MatrixA->pr[count - 1] = param->k1;
	}


	for (int i = 1; i <= N; i++)
	{
		MatrixA->ir[count++] = i - 1;
		MatrixA->pr[count - 1] = param->l1[i - 1];
		MatrixA->ir[count++] = N + i - 1;
		MatrixA->pr[count - 1] = param->l2[i - 1];
		MatrixA->ir[count++] = 2 * N + i - 1;
		MatrixA->pr[count - 1] = param->l3[i - 1];
		MatrixA->ir[count++] = 3 * N + i - 1;
		MatrixA->pr[count - 1] = param->l4[i - 1];
		MatrixA->ir[count++] = 4 * N + i - 1;
		MatrixA->pr[count - 1] = param->l5[i - 1];
		MatrixA->ir[count++] = 5 * N + i - 1;
		MatrixA->pr[count - 1] = param->l6[i - 1];
		MatrixA->ir[count++] = 6 * N + i - 1;
		MatrixA->pr[count - 1] = param->l7[i - 1];
		MatrixA->ir[count++] = 7 * N + i - 1;
		MatrixA->pr[count - 1] = param->l8[i - 1];
		MatrixA->ir[count++] = 8 * N + i - 1;
		MatrixA->pr[count - 1] = param->l9[i - 1];
	}
}


pfloat* Generate_Vectorb(A_param *param, idxint N, trajectory* oldtrac)
{

	pfloat* b = (pfloat*)MALLOC(sizeof(pfloat) * (9 * N + 18));


	for (int i = 1; i <= N; i++)
	{
		b[0 * N + i - 1] = param->b1[i - 1];
		b[1 * N + i - 1] = param->b2[i - 1];
		b[2 * N + i - 1] = param->b3[i - 1];
		b[3 * N + i - 1] = param->b4[i - 1];
		b[4 * N + i - 1] = param->b5[i - 1];
		b[5 * N + i - 1] = param->b6[i - 1];
		b[6 * N + i - 1] = param->b7[i - 1];
		b[7 * N + i - 1] = param->b8[i - 1];
		b[8 * N + i - 1] = param->b9[i - 1];
	}


	b[9 * N] = 0;
	b[9 * N + 1] = 0;
	b[9 * N + 2] = 0;
	b[9 * N + 3] = 0;
	b[9 * N + 4] = 0;
	b[9 * N + 5] = 0;
	b[9 * N + 6] = 0;
	b[9 * N + 7] = 0;
	b[9 * N + 8] = Mass * g;

	b[9 * N + 9] = 40;
	b[9 * N + 10] = 38;
	b[9 * N + 11] = 45;
	b[9 * N + 12] = 0;
	b[9 * N + 13] = 0;
	b[9 * N + 14] = 0;
	b[9 * N + 15] = 0;
	b[9 * N + 16] = 0;
	b[9 * N + 17] = Mass * g;
	return b;
}


void Update_Vectorb(pfloat *b, A_param *param, idxint N, trajectory *oldtrac)
{

	for (int i = 1; i <= N; i++)
	{
		b[0 * N + i - 1] = param->b1[i - 1];
		b[1 * N + i - 1] = param->b2[i - 1];
		b[2 * N + i - 1] = param->b3[i - 1];
		b[3 * N + i - 1] = param->b4[i - 1];
		b[4 * N + i - 1] = param->b5[i - 1];
		b[5 * N + i - 1] = param->b6[i - 1];
		b[6 * N + i - 1] = param->b7[i - 1];
		b[7 * N + i - 1] = param->b8[i - 1];
		b[8 * N + i - 1] = param->b9[i - 1];
	}


	b[9 * N] = 0;
	b[9 * N + 1] = 0;
	b[9 * N + 2] = 0;
	b[9 * N + 3] = 0;
	b[9 * N + 4] = 0;
	b[9 * N + 5] = 0;
	b[9 * N + 6] = 0;
	b[9 * N + 7] = 0;
	b[9 * N + 8] = Mass * g;

	b[9 * N + 9] = 40;
	b[9 * N + 10] = 38;
	b[9 * N + 11] = 45;
	b[9 * N + 12] = 0;
	b[9 * N + 13] = 0;
	b[9 * N + 14] = 0;
	b[9 * N + 15] = 0;
	b[9 * N + 16] = 0;
	b[9 * N + 17] = Mass * g;
}


pfloat* Generate_Vectorc(idxint N)
{

	pfloat* c = (pfloat*)MALLOC(sizeof(pfloat) * (12 * N + 10));


	for (int i = 0; i < 12 * N + 9; i++)
	{
		c[i] = 0;
	}

	c[12 * N + 9] = 1;

	return c;
}


void Update_Vectorc(pfloat *c, idxint N)
{
	c[12 * N + 9] = 1;
}



spmat* Generate_MatrixG(A_param* param, idxint N)
{

	spmat* MatrixG = (spmat*)MALLOC(sizeof(spmat));

	MatrixG->m = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + 4 * N;

	MatrixG->n = 12 * N + 10;

	MatrixG->nnz = 18 * N + 18 + 6 * N + 2 + 8 * N + 8 + 3 * N;

	MatrixG->jc = (idxint*)MALLOC(sizeof(idxint)*(MatrixG->n + 1));
	MatrixG->ir = (idxint*)MALLOC(sizeof(idxint)*(MatrixG->nnz));
	MatrixG->pr = (pfloat*)MALLOC(sizeof(pfloat)*(MatrixG->nnz));


	MatrixG->jc[0] = 0;


	for (int i = 1; i <= 2 * N + 2; i++)
	{
		MatrixG->jc[i] = MatrixG->jc[i - 1] + 6;
	}


	for (int i = 2 * N + 3; i <= 3 * N + 3; i++)
	{
		MatrixG->jc[i] = MatrixG->jc[i - 1] + 2;
	}


	for (int i = 3 * N + 4; i <= 6 * N + 6; i++)
	{
		MatrixG->jc[i] = MatrixG->jc[i - 1] + 2;
	}


	for (int i = 6 * N + 7; i <= 9 * N + 9; i++)
	{
		if (i % (N + 1) == 0)
		{
			MatrixG->jc[i] = MatrixG->jc[i - 1] + 2;
		}
		else
		{
			MatrixG->jc[i] = MatrixG->jc[i - 1] + 3;
		}
	}


	for (int i = 9 * N + 10; i <= 12 * N + 9; i++)
	{
		MatrixG->jc[i] = MatrixG->jc[i - 1] + 2;
	}


	for (int i = 12 * N + 10; i <= 12 * N + 10; i++)
	{
		MatrixG->jc[i] = MatrixG->jc[i - 1] + 2;
	}


	int count = 0;


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = N + 1 + i - 1;
		MatrixG->pr[count - 1] = -1;
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s1_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + N + 1 + i - 1;
		MatrixG->pr[count - 1] = param->s2_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s3_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = param->s4_x[i - 1];
	}



	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = -1;
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s1_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + N + 1 + i - 1;
		MatrixG->pr[count - 1] = param->s2_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s3_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = param->s4_y[i - 1];
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 4 * N + 4 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 5 * N + 5 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}

	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 6 * N + 6 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 7 * N + 7 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 8 * N + 8 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 9 * N + 9 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}

	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 10 * N + 10 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 11 * N + 11 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 12 * N + 12 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 13 * N + 13 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 1;
			MatrixG->pr[count - 1] = -1;
		}
		
	}

	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 14 * N + 14 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 15 * N + 15 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 2;
			MatrixG->pr[count - 1] = -1;
		}
		
	}

	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 16 * N + 16 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 17 * N + 17 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 3;
			MatrixG->pr[count - 1] = -1;
		}
		
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + 2 * N + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + 3 * N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + 4 * N + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + 5 * N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}

	

	MatrixG->ir[count++] = 18 * N + 18 + 6 * N;
	MatrixG->pr[count - 1] = 1;
	MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 1;
	MatrixG->pr[count - 1] = -1;

	return MatrixG;
}




void Update_MatrixG(spmat *MatrixG, A_param* param, idxint N)
{

	int count = 0;


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = N + 1 + i - 1;
		MatrixG->pr[count - 1] = -1;
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s1_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + N + 1 + i - 1;
		MatrixG->pr[count - 1] = param->s2_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s3_x[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = param->s4_x[i - 1];
	}



	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = -1;
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s1_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + N + 1 + i - 1;
		MatrixG->pr[count - 1] = param->s2_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 2 * N + 2 + i - 1;
		MatrixG->pr[count - 1] = param->s3_y[i - 1];
		MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 3 * N + 3 + i - 1;
		MatrixG->pr[count - 1] = param->s4_y[i - 1];
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 4 * N + 4 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 5 * N + 5 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 6 * N + 6 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 7 * N + 7 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 8 * N + 8 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 9 * N + 9 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 10 * N + 10 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 11 * N + 11 + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 12 * N + 12 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 13 * N + 13 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 1;
			MatrixG->pr[count - 1] = -1;
		}

	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 14 * N + 14 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 15 * N + 15 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 2;
			MatrixG->pr[count - 1] = -1;
		}

	}


	for (int i = 1; i <= N + 1; i++)
	{
		MatrixG->ir[count++] = 16 * N + 16 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 17 * N + 17 + i - 1;
		MatrixG->pr[count - 1] = -1;
		if (i < N + 1)
		{
			MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + (i - 1) * 4 + 3;
			MatrixG->pr[count - 1] = -1;
		}

	}

	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}

	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + 2 * N + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + 3 * N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}


	for (int i = 1; i <= N; i++)
	{
		MatrixG->ir[count++] = 18 * N + 18 + 4 * N + i - 1;
		MatrixG->pr[count - 1] = 1;
		MatrixG->ir[count++] = 18 * N + 18 + 5 * N + i - 1;
		MatrixG->pr[count - 1] = -1;
	}



	MatrixG->ir[count++] = 18 * N + 18 + 6 * N;
	MatrixG->pr[count - 1] = 1;
	MatrixG->ir[count++] = 18 * N + 18 + 6 * N + 1;
	MatrixG->pr[count - 1] = -1;
}


pfloat* Generate_Vectorh(idxint N, A_param* param, trajectory *oldtrac, control* oldcontr)
{

	pfloat* h = (pfloat*)MALLOC(sizeof(pfloat) * (18 * N + 18 + 6 * N + 2 + 4 * N + 4 + 4 * N));

	for (int i = 1; i <= N + 1; i++)
	{

		h[0 * (N + 1) + i - 1] = delta_x;
		h[1 * (N + 1) + i - 1] = delta_x;
		h[2 * (N + 1) + i - 1] = delta_y;
		h[3 * (N + 1) + i - 1] = delta_y;
		h[4 * (N + 1) + i - 1] = delta_z;
		h[5 * (N + 1) + i - 1] = delta_z;
		h[6 * (N + 1) + i - 1] = delta_Vx;
		h[7 * (N + 1) + i - 1] = delta_Vx;
		h[8 * (N + 1) + i - 1] = delta_Vy;
		h[9 * (N + 1) + i - 1] = delta_Vy;
		h[10 * (N + 1) + i - 1] = delta_Vz;
		h[11 * (N + 1) + i - 1] = delta_Vz;
		h[12 * (N + 1) + i - 1] = delta_ux;
		h[13 * (N + 1) + i - 1] = delta_ux;
		h[14 * (N + 1) + i - 1] = delta_uy;
		h[15 * (N + 1) + i - 1] = delta_uy;
		h[16 * (N + 1) + i - 1] = delta_uz;
		h[17 * (N + 1) + i - 1] = delta_uz;
	}

	for (int i = 1; i <= N; i++)
	{

		h[18 * (N + 1) + 0 * N + i - 1] = delta_dux;
		h[18 * (N + 1) + 1 * N + i - 1] = delta_dux;
		h[18 * (N + 1) + 2 * N + i - 1] = delta_duy;
		h[18 * (N + 1) + 3 * N + i - 1] = delta_duy;
		h[18 * (N + 1) + 4 * N + i - 1] = delta_duz;
		h[18 * (N + 1) + 5 * N + i - 1] = delta_duz;
	}



	h[18 * (N + 1) + 6 * N + 0] = delta_tf;
	h[18 * (N + 1) + 6 * N + 1] = 0;

	for (int i = 1; i <= N + 1; i++)
	{
		h[18 * (N + 1) + 6 * N + 2 + 0 * (N + 1) + i - 1] = -param->S_1[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 1 * (N + 1) + i - 1] = -param->S_2[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 2 * (N + 1) + i - 1] = -param->S_3[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 3 * (N + 1) + i - 1] = -param->S_4[i - 1];
	}
	

	idxint start = 18 * (N + 1) + 6 * N + 2 + 4 * (N + 1);
	for (int i = 0; i < 4 * N; i++)
	{
		if (i % 4 == 0)
		{
			h[start + i] = U1_max * U1_max;
		}
		else
		{
			h[start + i] = 0;
		}
	}

	return h;
}

/*���ݲ���ԭ�ظ���h����*/
void Update_Vectorh(pfloat *h, idxint N, A_param* param, trajectory * oldtrac, control* oldcontr)
{

	for (int i = 1; i <= N + 1; i++)
	{


		h[0 * (N + 1) + i - 1] = delta_x;
		h[1 * (N + 1) + i - 1] = delta_x;
		h[2 * (N + 1) + i - 1] = delta_y;
		h[3 * (N + 1) + i - 1] = delta_y;
		h[4 * (N + 1) + i - 1] = delta_z;
		h[5 * (N + 1) + i - 1] = delta_z;
		h[6 * (N + 1) + i - 1] = delta_Vx;
		h[7 * (N + 1) + i - 1] = delta_Vx;
		h[8 * (N + 1) + i - 1] = delta_Vy;
		h[9 * (N + 1) + i - 1] = delta_Vy;
		h[10 * (N + 1) + i - 1] = delta_Vz;
		h[11 * (N + 1) + i - 1] = delta_Vz;
		h[12 * (N + 1) + i - 1] = delta_ux;
		h[13 * (N + 1) + i - 1] = delta_ux;
		h[14 * (N + 1) + i - 1] = delta_uy;
		h[15 * (N + 1) + i - 1] = delta_uy;
		h[16 * (N + 1) + i - 1] = delta_uz;
		h[17 * (N + 1) + i - 1] = delta_uz;
	}

	for (int i = 1; i <= N; i++)
	{

		h[18 * (N + 1) + 0 * N + i - 1] = delta_dux;
		h[18 * (N + 1) + 1 * N + i - 1] = delta_dux;
		h[18 * (N + 1) + 2 * N + i - 1] = delta_duy;
		h[18 * (N + 1) + 3 * N + i - 1] = delta_duy;
		h[18 * (N + 1) + 4 * N + i - 1] = delta_duz;
		h[18 * (N + 1) + 5 * N + i - 1] = delta_duz;
	}



	h[18 * (N + 1) + 6 * N + 0] = delta_tf;
	h[18 * (N + 1) + 6 * N + 1] = 0;

	for (int i = 1; i <= N + 1; i++)
	{
		h[18 * (N + 1) + 6 * N + 2 + 0 * (N + 1) + i - 1] = -param->S_1[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 1 * (N + 1) + i - 1] = -param->S_2[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 2 * (N + 1) + i - 1] = -param->S_3[i - 1];
		h[18 * (N + 1) + 6 * N + 2 + 3 * (N + 1) + i - 1] = -param->S_4[i - 1];
	}


	idxint start = 18 * (N + 1) + 6 * N + 2 + 4 * (N + 1);
	for (int i = 0; i < 4 * N; i++)
	{
		if (i % 4 == 0)
		{
			h[start + i] = U1_max * U1_max;
		}
		else
		{
			h[start + i] = 0;
		}
	}
}


optimize_parameters* GetAllParamers(trajectory *oldtrac, control* oldcontr, idxint N)
{

	optimize_parameters* all_param = (optimize_parameters*)MALLOC(sizeof(optimize_parameters));


	all_param->n = 12 * N + 10;


	all_param->p = 9 * N + 18;


	all_param->m = 18 * N + 18 + 6 * N + 2 + 4 * N + 4 + 4 * N;


	all_param->l = 18 * N + 18 + 6 * N + 2 + 4 * N + 4;


	all_param->n_cones = N;


	all_param->q = (idxint*)MALLOC(sizeof(idxint)*(N));
	for (int i = 0; i < N; i++)
	{
		all_param->q[i] = 4;
	}



	A_param *a_param = GetMatrixA_Param(oldtrac, oldcontr, N);

	

	all_param->c = Generate_Vectorc(N);


	all_param->b = Generate_Vectorb(a_param, N, oldtrac);


	all_param->h = Generate_Vectorh(N, a_param, oldtrac, oldcontr);


	all_param->D = GetRadua_MatrixD(N);
	all_param->A = Generate_MatrixA(all_param->D, a_param, N);


	all_param->G = Generate_MatrixG(a_param, N);



	FREE(a_param->l1);
	FREE(a_param->b1);
	FREE(a_param->l2);
	FREE(a_param->b2);
	FREE(a_param->l3);
	FREE(a_param->b3);
	FREE(a_param->l4);
	FREE(a_param->b4);
	FREE(a_param->l5);
	FREE(a_param->b5);
	FREE(a_param->l6);
	FREE(a_param->b6);
	FREE(a_param->l7);
	FREE(a_param->b7);
	FREE(a_param->l8);
	FREE(a_param->b8);
	FREE(a_param->l9);
	FREE(a_param->b9);
	FREE(a_param->s1_x);
	FREE(a_param->s2_x);
	FREE(a_param->s3_x);
	FREE(a_param->s4_x);
	FREE(a_param->s1_y);
	FREE(a_param->s2_y);
	FREE(a_param->s3_y);
	FREE(a_param->s4_y);
	FREE(a_param->s_1);
	FREE(a_param->s_2);
	FREE(a_param->s_3);
	FREE(a_param->s_4);
	FREE(a_param->S_1);
	FREE(a_param->S_2);
	FREE(a_param->S_3);
	FREE(a_param->S_4);
	FREE(a_param);

	return all_param;
}
