#include "ecos_solver.h"



pwork * ecos_setup_optimization(optimize_parameters *para)
{
	return ECOS_setup(para->n, para->m, para->p, para->l, para->n_cones, para->q, 0, para->G->pr, para->G->jc, para->G->ir, para->A->pr, para->A->jc, para->A->ir, para->c, para->h, para->b);
}


idxint ecos_solve_optimazation(pwork *work, trajectory *traj, control *contr)
{

	idxint exitflag = ECOS_solve(work);
	int k = 0;

	for (int i = 0; i < COLL_NUM + 1; i++) traj->x[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->y[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->z[i] = work->x[k++];

	for (int i = 0; i < COLL_NUM + 1; i++) traj->Vx[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->Vy[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->Vz[i] = work->x[k++];

	for (int i = 0; i < COLL_NUM + 1; i++) traj->ux[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->uy[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM + 1; i++) traj->uz[i] = work->x[k++];


	for (int i = 0; i < COLL_NUM; i++) contr->dux[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM; i++) contr->duy[i] = work->x[k++];
	for (int i = 0; i < COLL_NUM; i++) contr->duz[i] = work->x[k++];

	traj->tf = work->x[k++];

	return exitflag;
}


void update_optimization(pwork *work, optimize_parameters *para)
{
	ECOS_updateData(work, para->G->pr, para->A->pr,
		para->c, para->h, para->b);
}


void optimization_cleanup(pwork *work, optimize_parameters *para, trajectory *traj, control *contr, trajectory *old_traj)
{

	ECOS_cleanup(work, 0);


	free(para->q);
	free(para->c);
	free(para->b);
	free(para->h);
	free(para->A->jc);
	free(para->A->ir);
	free(para->A->pr);
	free(para->G->jc);
	free(para->G->ir);
	free(para->G->pr);


	for (int i = 0; i < COLL_NUM; i++) free(para->D[i]);
	free(para->D);
	free(para);


	FREE(traj->time);
	FREE(traj->x);
	FREE(traj->y);
	FREE(traj->z);
	FREE(traj->Vx);
	FREE(traj->Vy);
	FREE(traj->Vz);
	FREE(traj->ux);
	FREE(traj->uy);
	FREE(traj->uz);
	FREE(traj);

	FREE(old_traj->time);
	FREE(old_traj->x);
	FREE(old_traj->y);
	FREE(old_traj->z);
	FREE(old_traj->Vx);
	FREE(old_traj->Vy);
	FREE(old_traj->Vz);
	FREE(old_traj->ux);
	FREE(old_traj->uy);
	FREE(old_traj->uz);
	FREE(old_traj);

	FREE(contr->dux);
	FREE(contr->duy);
	FREE(contr->duz);
	FREE(contr);
}
