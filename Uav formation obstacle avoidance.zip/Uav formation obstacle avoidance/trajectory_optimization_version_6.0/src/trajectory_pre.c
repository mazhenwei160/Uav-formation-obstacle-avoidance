#pragma once
#pragma warning(disable : 4996)
#include "trajectory_pre.h"


trajectory *prepare_trajectory(pfloat t0, int COLL_NUM, int traj_length)
{

	trajectory * stand_traj = read_standered_trajectory(traj_length);


	trajectory * GD_traj_D = init_trajectory(stand_traj, t0, COLL_NUM, traj_length);


	GD_traj_D->tf = 7.60;

	FREE(stand_traj->time);
	FREE(stand_traj->x);
	FREE(stand_traj->y);
	FREE(stand_traj->z);
	FREE(stand_traj->Vx);
	FREE(stand_traj->Vy);
	FREE(stand_traj->Vz);
	FREE(stand_traj->ux);
	FREE(stand_traj->uy);
	FREE(stand_traj->uz);
	FREE(stand_traj);

	return GD_traj_D;
}


trajectory *read_standered_trajectory(int traj_length)
{

	trajectory *stand_traj = (trajectory*)MALLOC(sizeof(trajectory));
	stand_traj->time  = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->x     = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->y     = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->z     = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->Vx    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->Vy    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->Vz    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->ux    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->uy    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	stand_traj->uz    = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);


	FILE *fp = fopen("input/standered_trajectory.csv", "r");
	if (fp == NULL)
	{
		printf("fail to open file");
		return NULL;
	}

	char buffer[2048];     
	char *line = NULL;      
	char *element;          
	int idx = 0;          


	while (line = fgets(buffer, sizeof(buffer), fp))       
	{
		element = strtok(line, ",");                    

		stand_traj->time[idx] = atof(element); 
		element = strtok(NULL, ",");

		stand_traj->x[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->y[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->z[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->Vx[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->Vy[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->Vz[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->ux[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->uy[idx] = atof(element);
		element = strtok(NULL, ",");

		stand_traj->uz[idx] = atof(element);
		element = strtok(NULL, ",");

		idx++;
	}
	fclose(fp);
	return stand_traj;
}


trajectory *init_trajectory(trajectory *stand_traj, pfloat start_time, int N, int traj_length)
{

	trajectory * GD_traj_D = (trajectory*)MALLOC(sizeof(trajectory));
	GD_traj_D->time  = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->x     = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->y     = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->z     = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->Vx    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->Vy    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->Vz    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->ux    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->uy    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	GD_traj_D->uz    = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));

	const pfloat eps_tau = 1e-15;
	pfloat old_Tau;
	pfloat* Tau = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));
	pfloat* P = (pfloat*)MALLOC(sizeof(pfloat) * (N + 1));

	for (int i = 0; i < N; i++) Tau[i] = -cos(2 * PI * i / (2 * N - 1));

	for (int i = 1; i < N; i++)
	{
		old_Tau = 2.0;

		while (fabs(Tau[i] - old_Tau) > eps_tau)
		{
			old_Tau = Tau[i];

			P[0] = 1;
			P[1] = Tau[i];
			for (int j = 1; j < N; j++)
			{
				P[j+1] = ((2*j+1) * Tau[i] * P[j] - j*P[j-1]) / (j+1);
			}
			Tau[i] = old_Tau - (Tau[i] - 1) * (P[N] + P[N - 1]) / (P[N] - P[N - 1]) / N;
		}
	}
	Tau[N] = 1.0;

	int start_index = start_time + 0.5;             
	int end_index = traj_length - 1;                 
	
	for (int i=0; i <= N; i++)
	{

		int offset = (int)(((Tau[i] - Tau[0]) / 2) * (end_index - start_index) + start_index + 0.5);

		GD_traj_D->time[i] = stand_traj->time[offset];
		GD_traj_D->x[i]    = stand_traj->x[offset];
		GD_traj_D->y[i]    = stand_traj->y[offset];
		GD_traj_D->z[i]    = stand_traj->z[offset];
		GD_traj_D->Vx[i]   = stand_traj->Vx[offset];
		GD_traj_D->Vy[i]   = stand_traj->Vy[offset];
		GD_traj_D->Vz[i]   = stand_traj->Vz[offset];
		GD_traj_D->ux[i]   = stand_traj->ux[offset];
		GD_traj_D->uy[i]   = stand_traj->uy[offset];
		GD_traj_D->uz[i]   = stand_traj->uz[offset];
	}


	FREE(P);
	FREE(Tau);

	return GD_traj_D;
}


control* read_standard_control(idxint N, int traj_length, pfloat start_time)
{

	control* contr = (control*)MALLOC(sizeof(control));
	contr->dux = (pfloat*)MALLOC(sizeof(pfloat) * N);
	contr->duy = (pfloat*)MALLOC(sizeof(pfloat) * N);
	contr->duz = (pfloat*)MALLOC(sizeof(pfloat) * N);


	control_stand* contr_stand = (control_stand*)MALLOC(sizeof(control_stand));
	contr_stand->time = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	contr_stand->dux = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	contr_stand->duy = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);
	contr_stand->duz = (pfloat*)MALLOC(sizeof(pfloat) * traj_length);



	FILE* fp = fopen("input/standered_control.csv", "r");
	if (fp == NULL)
	{
		printf("fail to open file");
		return NULL;
	}

	char buffer[2048];
	char* line = NULL;
	char* element;
	int idx = 0;

	while (line = fgets(buffer, sizeof(buffer), fp))
	{
		element = strtok(line, ",");

		contr_stand->time[idx] = atof(element);
		element = strtok(NULL, ",");

		contr_stand->dux[idx] = atof(element);
		element = strtok(NULL, ",");

		contr_stand->duy[idx] = atof(element);
		element = strtok(NULL, ",");

		contr_stand->duz[idx] = atof(element);
		element = strtok(NULL, ",");
		idx++;
	}
	fclose(fp);




	pfloat* Tau = GetRadua_Tau(N);
	int start_index = start_time + 0.5;
	int end_index = traj_length - 1;
	for (int i = 0; i < N; i++)
	{

		int offset = (int)(((Tau[i] - Tau[0]) / 2) * (end_index - start_index) + start_index + 0.5);
		contr->dux[i] = contr_stand->dux[offset];
		contr->duy[i] = contr_stand->duy[offset];
		contr->duz[i] = contr_stand->duz[offset];
	}


	FREE(contr_stand->time);
	FREE(contr_stand->dux);
	FREE(contr_stand->duy);
	FREE(contr_stand->duz);
	FREE(contr_stand);

	FREE(Tau);

	return contr;
}