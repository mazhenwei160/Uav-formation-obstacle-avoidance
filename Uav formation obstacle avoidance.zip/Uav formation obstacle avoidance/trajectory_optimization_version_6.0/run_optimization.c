/*
*																				*
*               A joint guidance and control framework for                      *
*   autonomous obstacle avoidance in quadrotor formations under model uncertainty	*
*                                                                               * 
*                                                                               *
*/

#pragma once
#pragma warning(disable : 4996)
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "ecos.h"
#include "trajectory_optimization.h"
#include "trajectory_pre.h"
#include "ecos_solver.h"

void  main(void)
{

	bool IF_DEBUG = false;


	idxint exitcode ;


	printf("Please enter the number of collocation point��\n");
	scanf("%d", &COLL_NUM);




	pfloat t0 = 0.0;


	int stand_traj_length = 761;


	trajectory *GD_traj_D = prepare_trajectory(t0, COLL_NUM, stand_traj_length);


	trajectory *old_traj = (trajectory*)MALLOC(sizeof(trajectory));
	old_traj->time = (pfloat*)MALLOC(sizeof(pfloat) * (COLL_NUM + 1));
	old_traj->x			= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->y			= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->z			= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->Vx		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->Vy		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->Vz		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->ux		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->uy		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));
	old_traj->uz		= (pfloat*)MALLOC(sizeof(pfloat)*(COLL_NUM + 1));



	control* contr = read_standard_control(COLL_NUM, stand_traj_length, t0);


	optimize_parameters *para = parameterization(GD_traj_D, contr);
	

	pwork* my_work = ecos_setup_optimization(para);
	clock_t begin, end;
	begin = clock();


	do {

		printf("===============================================================\n");
		printf("Number of iterations: %d\n", ITER_NUM);	


		copy_trajectory(GD_traj_D, old_traj);


		exitcode = ecos_solve_optimazation(my_work, GD_traj_D, contr);


		update_parameters(para, GD_traj_D, contr);


		update_optimization(my_work, para);


		if (IF_DEBUG)
		{

			save_trajectory_control_iter(ITER_NUM, GD_traj_D, contr);
		}	

		ITER_NUM++;


	} while (!check_convergence(old_traj, GD_traj_D) && ITER_NUM < MAX_ITER_NUM);

	end = clock();
	double cost_time = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("iter_time: %.3f\n", cost_time);

	if (IF_DEBUG)
	{

		save_iterN(ITER_NUM);
	}



	save_optimal_solution(GD_traj_D, contr);
	


	optimization_cleanup(my_work, para, GD_traj_D, contr,old_traj);

}

